from socket import *
import os

# Coloque aqui as configurações do Socket do cliente
clienteSocket = socket(AF_INET, SOCK_STREAM)
ip = str(input("Digite o endereço IP do servidor: "))
porta = int(input("Digite a porta do servidor: "))
clienteSocket.connect((ip,porta))
contador = 0

# Loop principal
while True:
    # if (os.name == 'nt'):
    #     os.system('cls')
    # else:
    #     os.system('clear')
    if contador == 0:
        message = clienteSocket.recv(1024).decode() # Usuário / Jogadas
        print(message)

        texto = input("-> ")
        clienteSocket.send(texto.encode())
        message = clienteSocket.recv(1024).decode() # Olá usuario, aguarde o seu oponente
        print(message)

        mensagemUsuario = clienteSocket.recv(1024).decode() # Jogadores conectados!
        print(mensagemUsuario)

        contador +=1

    elif contador == 1:
        print("elif")
        table = clienteSocket.recv(1024).decode() # tabela
        print(table)

        msgTurno = clienteSocket.recv(1024).decode() # Faça a sua jogada / Aguarde a sua vez

        acao = msgTurno[-6:] # jogada / calmou
        if acao == "jogada":
            print("dentro if")
            print(msgTurno[:-6])
            valor = input("-->")
            clienteSocket.send(valor.encode())
        else:
            print("dentro else")
            print(msgTurno[:-6])

    else:
        print("else")
        table = clienteSocket.recv(1024).decode()
        print(table)
        msgTurno = clienteSocket.recv(1024).decode()
        print(msgTurno)
        valor = input("->")
        clienteSocket.send(valor.encode())

    
    #Terceira mensagem server
    
    # 3- o servidor enviou uma mensagem dizendo que a jogada é inválida e pedindo para refazer a jogada

    # O código aqui embaixo verifica se existe a string "FIM" na mensagem enviada pelo servidor
    # (indicando o fim do jogo) e sai do loop para fechar a conexão
    if "FIM" in message:
        break
clienteSocket.close()
