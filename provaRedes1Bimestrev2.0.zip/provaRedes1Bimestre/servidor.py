# Equipe:
# Andre Felipe
# Luis Fernando
# Thiago Antonio

from socket import *
from threading import Thread
from time import sleep
import random

serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
serverSocket.bind(('127.0.0.1',2222))
serverSocket.listen(5)

def mainSocket():
    nPlayers = 0
    connections = []
    players = []
    while True:
        print("Aguardando jogadores...")
        bindSocket, addr = serverSocket.accept()
        print(f"Conexão recebida em {addr[0]}:{addr[1]}")

        mensagem = "Qual o seu nome? "
        bindSocket.send(mensagem.encode())
        usuario = bindSocket.recv(1024).decode()

        mensagemUsuario = f"Olá {usuario}, aguarde o seu oponente!\n"
        bindSocket.send(mensagemUsuario.encode())
        players.append(usuario)
        nPlayers = nPlayers+1
        connections.append(bindSocket)

        if (nPlayers > 1):
            for i in connections:
                i.send("Jogadores conectados! Jogo iniciando...\n".encode())
            sleep(1)
            t = Thread(target=proxy, args=[connections, players])
            t.start()
            t.join()
            nPlayers = 0
            connections.clear()
            players.clear()

def proxy(connections, players):
    table = [['','',''],['','',''],['','','']]
    # aleatorio = random.randint(0,1)
    aleatorio = 0
    turnos = 9

    while True:
        if turnos == 0: #empate
            break
        
        elif turnos%2 != 0: 
            print("Turno: ", turnos)
            msg = formatTable(table)
            for i in connections:
                i.send(msg.encode())
            
            if aleatorio == 0:
                print("par 0")
                msgTurno = f"Olá {players[aleatorio]}, é a sua vez de jogar! [linha, coluna]"
                msgAguarde = f"Olá {players[aleatorio+1]}, aguarde a sua vez!"
                acao = "jogada"
                acao2 = "calmou"

                connections[aleatorio].send(msgTurno.encode()) #enviando o nome doq comeca
                connections[aleatorio+1].send(msgAguarde.encode())

                connections[aleatorio].send(acao.encode()) #enviando a acao doq comeca
                connections[aleatorio+1].send(acao2.encode()) 

                coordenada = connections[aleatorio].recv(1024).decode() #1,1
                coordenadaSeparada = coordenada.split(",")
                linha= int(coordenadaSeparada[0])
                coluna = int(coordenadaSeparada[1])
                
                msg = formatTable(table)
                for i in connections:
                    i.send(msg.encode())

                aleatorio = 1
            else:
                print("par 1")
                msgTurno = f"Olá {players[aleatorio]}, é a sua vez de jogar! [linha, coluna]"
                msgAguarde = f"Olá {players[aleatorio-1]}, aguarde a sua vez!"
                acao = "jogada"
                acao2 = "calmou"

                connections[aleatorio].send(msgTurno.encode()) #enviando o nome doq comeca
                connections[aleatorio-1].send(msgAguarde.encode())

                connections[aleatorio].send(acao.encode()) #enviando a acao doq comeca
                connections[aleatorio-1].send(acao2.encode()) 

                coordenada = connections[aleatorio].recv(1024).decode()
                msg = formatTable(table)
                for i in connections:
                    i.send(msg.encode())

                aleatorio = 0
            turnos -= 1
        else:
            print("Turno: ", turnos)
            if aleatorio == 0:
                print("impar 0")
                msgTurno = f"Olá {players[aleatorio]}, é a sua vez de jogar! [linha, coluna]"
                msgAguarde = f"Olá {players[aleatorio+1]}, aguarde a sua vez!"
                acao = "jogada"
                acao2 = "calmou"

                connections[aleatorio].send(msgTurno.encode()) #enviando o nome doq comeca
                connections[aleatorio+1].send(msgAguarde.encode())

                connections[aleatorio].send(acao.encode()) #enviando a acao doq comeca
                connections[aleatorio+1].send(acao2.encode()) 

                coordenada = connections[aleatorio].recv(1024).decode()

                msg = formatTable(table)
                for i in connections:
                    i.send(msg.encode())

                aleatorio = 1
            else:
                print("impar 1")
                msgTurno = f"Olá {players[aleatorio]}, é a sua vez de jogar! [linha, coluna]"
                msgAguarde = f"Olá {players[aleatorio-1]}, aguarde a sua vez!"
                acao = "jogada"
                acao2 = "calmou"

                connections[aleatorio].send(msgTurno.encode()) #enviando o nome doq comeca
                connections[aleatorio-1].send(msgAguarde.encode())

                connections[aleatorio].send(acao.encode()) #enviando a acao doq comeca
                connections[aleatorio-1].send(acao2.encode()) 

                coordenada = connections[aleatorio].recv(1024).decode()

                msg = formatTable(table)
                for i in connections:
                    i.send(msg.encode())

                aleatorio = 0
            
            turnos -= 1
            

        #recebimento
            
        # Aqui vai toda a parte lógica do jogo, onde o servidor envia e recebe mensagens. O servidor
        # envia e recebe mensagens de um jogador por vez. Podem ocorrer 3 situações na troca de 
        # mensagens:
        # Um jogador ganhou - a partida acaba e deve-se informar para os jogadores quem ganhou



        # Ninguém ganhou - a partida acaba e deve-se informar aos jogadores que ninguém ganhou



        # Jogadas normais - aqui o servidor solicita a coordenada das jogadas e as verifica. Tem
        #                   uma função 'checkOption()' lá embaixo que já faz essas verificações.
        #                   Caso a jogada não seja válida, o programa deve informar o
        #                   erro e pedir para o usuário digitar novamente.



        
# Função que 'cria' o tabuleiro para exibição (NÃO PRECISA MEXER AQUI)
def formatTable(table):
    msg = ""
    lineCount = 0
    for line in table:
        msg += ' '
        # Desenha cada linha do tabuleiro percorrendo as colunas
        for col in range(0, len(line)):
            if (line[col] == ''):
                msg += ' '
            elif(line[col] == 0):
                msg += 'X'
            elif(line[col] == 1):
                msg += 'O'
            if col < 2:
                msg += ' | '
        if lineCount < 2:
            msg += "\n-----------\n"
            lineCount += 1
    return msg

def checkOption(table, line, col):
    if not (0 <= line <=2) or not (0 <= col <= 2):
        return 2
    if table[line][col] != '':
        return 1
    return 0


# Função para verificar se alguém ganhou ou não
def checkTable(table):
    if table[0][0] == "X" and table[0][1] == "X"  and table[0][2] == "X" or table[1][0] == "X" and table[1][1] == "X"  and table[1][2] == "X" or table[2][0] == "X" and table[2][1] == "X"  and table[2][2] == "X":
        return "X ganhou" #por linhas
    
    elif table[0][0] == "X" and table[1][0] == "X" and table[2][0] == "X" or table[0][1] == "X" and table[1][1] == "X" and table[2][1] == "X" or table[0][2] == "X" and table[1][2] == "X" and table[2][2] == "X":
        return "X ganhou" #por colunas
    
    elif table[0][0] == "X" and table[1][1] == "X" and table[2][2] == "X" or table[0][2] == "X" and table[1][1] == "X" and table[2][0] == "X":
        return "X ganhou" #por diagonais
    
    elif table[0][0] == "O" and table[0][1] == "O"  and table[0][2] == "O" or table[1][0] == "O" and table[1][1] == "O"  and table[1][2] == "O" or table[2][0] == "O" and table[2][1] == "O"  and table[2][2] == "O":
        return "O ganhou" #por linhas
    
    elif table[0][0] == "O" and table[1][0] == "O" and table[2][0] == "O" or table[0][1] == "O" and table[1][1] == "O" and table[2][1] == "O" or table[0][2] == "O" and table[1][2] == "O" and table[2][2] == "O":
        return "O ganhou" #por colunas
    
    elif table[0][0] == "O" and table[1][1] == "O" and table[2][2] == "O" or table[0][2] == "O" and table[1][1] == "O" and table[2][0] == "O":
        return "O ganhou" #por diagonais
    else:
        return "Empatou"

# Função principal de inicialização (NÃO PRECISA MEXER AQUI)
if __name__ == '__main__':
# Cria e inicializa a thread principal
    tMain = Thread(target=mainSocket)
    tMain.start()
