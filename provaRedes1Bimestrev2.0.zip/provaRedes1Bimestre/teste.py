a = [['andre', 'felipe', 'wonsik'],['andre', 'felipe', 'wonsik'],['andre', 'felipe', 'wonsik']]
print(a[1][2])