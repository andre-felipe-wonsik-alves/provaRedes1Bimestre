from socket import *
import os

# Coloque aqui as configurações do Socket do cliente
clienteSocket = socket(AF_INET, SOCK_STREAM)
ip = str(input("Digite o endereço IP do servidor: "))
porta = int(input("Digite a porta do servidor: "))
clienteSocket.connect((ip,porta))

# Loop principal
while True:
    print(os.name)   

    if (os.name == 'nt'):
        os.system('cls')
    else:
        os.system('clear')
    
    message = clienteSocket.recv(1024).decode()
    print(message)
    usuario = str(input("-> "))
    clienteSocket.send(usuario.encode())
    
    print(f"Olá {usuario}, seja bem vindo! Aguarde o oponente.")

    table = clienteSocket.recv(1024).decode()
    print(table)

    mensagemTurno = clienteSocket.recv(1024).decode()
    print(mensagemTurno)

    #Terceira mensagem server
    
    # 3- o servidor enviou uma mensagem dizendo que a jogada é inválida e pedindo para refazer a jogada

    # O código aqui embaixo verifica se existe a string "FIM" na mensagem enviada pelo servidor
    # (indicando o fim do jogo) e sai do loop para fechar a conexão
    if "FIM" in message:
        break
clienteSocket.close()
